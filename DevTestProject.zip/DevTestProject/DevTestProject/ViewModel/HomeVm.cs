﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DevTestProject.ViewModel
{
    public class HomeVm
    {
        public string ErrorMsg { get; set; }
    }
}